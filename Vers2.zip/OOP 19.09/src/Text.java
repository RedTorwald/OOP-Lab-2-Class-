public class Text {
    public final String text;

    public Text(String text) {
        this.text = text;
    }

    public int getCountSingleLetterWords() {
        if (text.isEmpty()) {
            return 0;
        }

        String alph = "АБВЖИКОСУЯабвжикосуя";
        int count = 0;

        for(int i = 0; i < alph.length(); ++i) {
            if (text.charAt(0) == alph.charAt(i) && text.charAt(1) == ' ' ||
                    text.charAt(text.length() - 1) == alph.charAt(i) && text.charAt(text.length() - 2) == ' ') {
                count++;
            }
        }

        for(int i = 1; i < text.length() - 1; ++i) {
            for(int j = 0; j < alph.length(); ++j) {
                if (text.charAt(i) == alph.charAt(j) &&
                        (text.charAt(i - 1) == ' ' || text.charAt(i - 1) == ',' || text.charAt(i - 1) == '.') &&
                        (text.charAt(i + 1) == ' ' || text.charAt(i + 1) == ',' || text.charAt(i + 1) == '.')) {
                    count++;
                }
            }
        }

        return count;
    }

    public String getTextWithoutSingleLetterWords() {
        if (text.isEmpty()) {
            return "(Ошибка! Введён пустой текст)";
        }

        String str = text;
        String alph = "АБВЖИКОСУЯабвжикосуя";

        for (int i = 0; i < alph.length(); ++i) {
            if (str.charAt(0) == alph.charAt(i) && str.charAt(1) == ' ') {
                str = str.replace(alph.charAt(i) + " ", "");
            } else if (str.charAt(str.length() - 1) == alph.charAt(i) && str.charAt(str.length() - 2) == ' ') {
                str = str.replace(" " + alph.charAt(i), "");
            }
        }

        for(int i = 1; i < str.length() - 1; ++i) {
            for(int j = 0; j < alph.length(); ++j) {
                if (str.charAt(i) == alph.charAt(j) &&
                        (str.charAt(i - 1) == ' ' || str.charAt(i - 1) == ',' || str.charAt(i - 1) == '.') &&
                        (str.charAt(i + 1) == ' ' || str.charAt(i + 1) == ',' || str.charAt(i + 1) == '.')) {
                    str = str.substring(0, i-1) + str.substring(i+1);
                }
            }
        }
        return str;
    }
    public String getLongestWord() {
        if (text.isEmpty()) {
            return "(Ошибка! Введён пустой текст)";
        }
        int count = 0;
        int maxCount = 0;
        int index = 0;
        int maxIndex = 0;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) != ' ' && text.charAt(i) != '.' && text.charAt(i) != ',') {
                count++;
                if (count == 1) {
                    index = i;
                }
                if (maxCount < count) {
                    maxIndex = index;
                    maxCount = count;
                }
            } else {
                count = 0;
            }
        }
        return text.substring(maxIndex, maxIndex + maxCount);
    }
}
