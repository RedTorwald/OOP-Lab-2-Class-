import java.util.Scanner;
class Matrix{
    private final int rows;
    private final int columns;
    private int[][] matrix;

    public Matrix(int N) {
        rows = columns = N;
        init();
    }
    public Matrix(int rows, int columns) {
        this.rows = rows;
        this.columns = columns;
        init();
    }
    public Matrix(int[][] matrix) {
        rows = matrix.length;
        columns = matrix[0].length;
        this.matrix = matrix;
    }

    private void init() {
        matrix = new int[rows][columns];
        Scanner in = new Scanner(System.in);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                matrix[i][j] = in.nextInt();
            }
        }
    }

    public int[][] getMinors() {
       // double det1 = 0;
        int[][] minors = new int[rows][columns];

        for (int r=0; r<rows; r++) {
            for (int c=0; c<columns; c++) {
                int[][] M = new int[rows-1][rows-1];

                for (int i=0, ii=0; i<rows; i++) {
                    if (i == r) continue;
                    for (int j=0, jj=0; j<rows; j++) {
                        if (j == c) continue;
                        M[ii][jj++] = matrix[i][j];
                    } ii++;
                }
                minors[r][c]=M[0][0]*M[1][1] - M[0][1]*M[1][0];
                System.out.print("|"+minors[r][c]+"|"+" ");
              //  det1 += (c % 2 == 0 ? -1 : 1) * matrix[c][0] * (new Matrix(M)).getDeterminant();
               // System.out.print("|"+det1+"|"+" ");
            }System.out.println();
        }
        return minors;
    }

    public void output() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                System.out.print("|"+matrix[i][j]+ "|"+ " ");
            }
            System.out.println();
        }
    }
    public void transpose() {
        int[][] temp=new int[rows][columns];

        for (int i = 0, ii=0; i < rows; i++){
            for (int j = 0, jj = 0; j < columns; j++) {
                temp[ii][jj++] = matrix[j][i];
            };
            ii++;
        } matrix=temp;
    }

    public double getDeterminant() {
        double det = 0;
        if (rows != columns) return 0;
        int size = rows;

        switch (size) {
            case 1: det = matrix[0][0]; break;
            case 2: det = matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0]; break;
            default: {
                for (int row = 0; row < size; row++) {

                    int[][] minor = new int[rows-1][rows-1];
                    for (int i=0, ii=0; i<rows; i++) {
                        if (i == row) continue;
                        for (int j=0, jj=0; j<rows; j++) {
                            if (j == 0) continue;
                            minor[ii][jj++] = matrix[i][j];
                        } ii++;
                    }
                    det += (row % 2 == 0 ? -1 : 1) * matrix[row][0] * (new Matrix(minor)).getDeterminant();
                }
            }
        }
        return det;
    }
    public int[][] getMinors1() {
        // double det1 = 0;
        int[][] minors = new int[rows][columns];

        for (int r=0; r<rows; r++) {
            for (int c=0; c<columns; c++) {
                int[][] M = new int[rows-1][rows-1];

                for (int i=0, ii=0; i<rows; i++) {
                    if (i == r) continue;
                    for (int j=0, jj=0; j<rows; j++) {
                        if (j == c) continue;
                        M[ii][jj++] = matrix[i][j];
                    } ii++;
                }
                new Matrix(M).getDeterminant();
                minors[r][c]=(int)new Matrix(M).getDeterminant();
                System.out.print("|"+minors[r][c]+"|"+" ");
               // minors[r][c]=M[0][0]*M[1][1] - M[0][1]*M[1][0];
               // System.out.print("|"+minors[r][c]+"|"+" ");
                //  det1 += (c % 2 == 0 ? -1 : 1) * matrix[c][0] * (new Matrix(M)).getDeterminant();
                // System.out.print("|"+det1+"|"+" ");
            }System.out.println();
        }
        return minors;
    }
}