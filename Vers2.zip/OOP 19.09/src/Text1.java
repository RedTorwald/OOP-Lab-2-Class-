import java.util.Scanner;

public class Text1 {

    public String text;
    public int counter;
    public int flag=0;

    public Text1(String text)
    {                                                                               // конструктор
        this.text = text;
    }

    public void input() {                                                          // функция ввода строки
        Scanner scan = new Scanner(System.in);
        String text = scan.nextLine();
    }

    public void getLine() {                                                       // готовая строка
        String text="Enter words keyboard. And another words. Test.";
    }

    public boolean nothing() {                                                   // проверка на пустую строку
        return text.isEmpty();
    }

    public int getSentenceCounter() {
        counter=0;
        for (int i = 1; i < text.length(); i++) {
            if (text.charAt(i) == '.' || text.charAt(i) == '!' || text.charAt(i) == '?') {
                counter++;
            }
        }
        return counter;
    }
    public int getWordCounter() {
        counter=0;
        for (int i = 1; i < text.length(); i++) {
            if (text.charAt(i)== ' ' || text.charAt(i)==  '.' || text.charAt(i) == '\t')
            {
                flag = 0;
            }
            else if(flag ==0) {
                flag = 1;
                counter++;
            }
        }
        return counter;
    }
}
