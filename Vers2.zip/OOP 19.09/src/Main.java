import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Введите размерность матрицы");
        int N= in.nextInt();
        System.out.println("Введите элементы матрицы");
        Matrix M=new Matrix(N);
        M.output();
        System.out.println("Det");
        System.out.println(M.getDeterminant());

        System.out.println("Minors");
        M.getMinors1();
        System.out.println("Transpose");
        M.transpose();
        M.output();
        //5 7 1 -4 1 0 2 0 3
        //1 2 3 4 5 6 7 8 9
        //1 4 2 8 8 5 9 1 5
        System.out.println("Введите элементы строки");
        Scanner scan = new Scanner(System.in);
        String text=scan.nextLine();
        Text1 txt=new Text1(text);
        if (txt.nothing())
        {
            System.out.println("empty");
        }
        else
        {
            System.out.println("Количество предложений в тексте");
            System.out.println(txt.getSentenceCounter());
            System.out.println("Количество слов в тексте ");
            System.out.println(txt.getWordCounter());
        }
    }
}